using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend.Models.tests
{
    public class TestType
    {
        public int TestTypeID { get; set; }
        public string TestTypeName { get; set; }
        public int TestTypeEnum { get; set; }
    }
}
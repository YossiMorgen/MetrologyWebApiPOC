using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend
{
    public class TestTemplate
    {
        public int TestTemplateID { get; set; }
        public string TestTemplateName { get; set; }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend
{
    public class TestSetDefinition
    {
        public int TestSetDefinitionID { get; set; }
        public string TestSetDefinitionName { get; set; }
        public int TestTypeID { get; set; }
    }
}
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend
{
    public class MeasurementResolution
    {
        public int MeasurementResolutionID { get; set; }
        public int Resolution { get; set; }
    }
}
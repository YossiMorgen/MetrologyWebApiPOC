using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace backend
{
    public class TestBoolean
    {
        public int TestBooleanID { get; set; }
        public bool IsIntact { get; set; }
        public bool IsDisqualify { get; set; }
        public string Description { get; set; }
    }
}
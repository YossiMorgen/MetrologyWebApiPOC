﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetrologyWebAPI.Models.ToolsDefinition
{
    public class Resolution
    {
        public int ResolutionID { get; set; }
        public double Value { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MetrologyWebAPI.Models.ToolsDefinition
{
    public class TestTemplatesDefinition
    {
        public int TestTemplatesDefinitionID { get; set; }
        public int TestTemplateID { get; set; }
        public int TestDefinitionID { get; set; }
    }
}